"""Compatibility entry point for promption.llm.ollama_client."""
from importlib import import_module
from pathlib import Path
import runpy
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
if __name__ == "__main__":
    runpy.run_module("promption.llm.ollama_client", run_name="__main__")
else:
    sys.modules[__name__] = import_module("promption.llm.ollama_client")
